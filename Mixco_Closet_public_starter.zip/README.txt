# Mixco Closet ♡ アイプリバース ミクコノート

スマホ向けのファンメイド・ミクコ検討サイトです。

## 公開方法（GitHub Pages）
1. GitHubにログインして、新しい **Public** repository を作成します。
2. このフォルダ内の `index.html` をアップロードします。
3. repository の **Settings → Pages** を開きます。
4. Build and deployment の Source で **Deploy from a branch** を選択します。
5. Branch を `main`、フォルダを `/(root)` にして Save。
6. 表示された Pages URL を開き、友達に共有します。

このサイトは静的HTMLです。各ユーザーの追加データ・所持状況・保存したミクコは、その人のブラウザ内に保存され、ユーザー間では共有されません。
公式サイトの画像を参照するサンプルを含みます。公開を続ける前に画像の利用条件を確認してください。権利者の許可が必要な場合は、許可を得た画像・自作画像に置き換えてください。
